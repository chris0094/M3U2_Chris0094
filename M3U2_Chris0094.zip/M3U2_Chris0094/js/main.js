import Kanban from "./view/Kanban.js";

new Kanban(
	document.querySelector(".kanban")
);
